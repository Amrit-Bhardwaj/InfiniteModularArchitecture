import Foundation
import FeatureOneInterface
import RouterServiceInterface
import UIKit

public class FeatureOneRouteHandler: RouteHandler {
    
    public init() {}
    
    public var routes: [Route.Type] {
        return [FeatureOneRoute.self]
    }

    public func destination(
        forRoute route: Route,
        fromViewController viewController: UIViewController
    ) -> Feature.Type {
        guard route is FeatureOneRoute else {
            preconditionFailure("unexpected route")
        }
        return FeatureOne.self
    }
}

