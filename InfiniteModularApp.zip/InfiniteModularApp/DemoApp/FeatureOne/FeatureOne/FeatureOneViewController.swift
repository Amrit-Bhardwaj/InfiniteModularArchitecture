import UIKit
import RouterServiceInterface
import HTTPClientInterface
import FeatureTwoInterface

// Feature One UI Screen
final public class FeatureOneViewController: UIViewController {

    let httpClient: HTTPClientProtocol
    let routerService: RouterServiceProtocol

    public init(
        httpClient: HTTPClientProtocol,
        routerService: RouterServiceProtocol
    ) {
        self.httpClient = httpClient
        self.routerService = routerService
        super.init(nibName: nil, bundle: nil)
        self.navigationItem.setHidesBackButton(true, animated: true)
    }
    
    // Navigate to feature two
    @objc private func goToFeatureTwo() {
        routerService.navigate(
            toRoute: FeatureTwoRoute(),
            fromView: self,
            presentationStyle: Push(),
            animated: true
        )
    }

    required init?(coder: NSCoder) {
        fatalError()
    }

    public override func loadView() {
        let view = UIView()

        view.backgroundColor = .yellow
        let featureLabel = UILabel()
        featureLabel.text = "FEATURE ONE"
        view.addSubview(featureLabel)
        featureLabel.translatesAutoresizingMaskIntoConstraints = false
        featureLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        featureLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 32).isActive = true
        let button = UIButton(type: .system)
        button.setTitle("Go to FeatureTwo", for: .normal)
        button.addTarget(self, action: #selector(goToFeatureTwo), for: .touchUpInside)
        view.addSubview(button)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 64).isActive = true
        self.view = view
    }
}
