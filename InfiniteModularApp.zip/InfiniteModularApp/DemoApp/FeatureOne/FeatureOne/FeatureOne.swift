import RouterServiceInterface
import HTTPClientInterface
import FeatureTwoInterface
import UIKit

public struct FeatureOne: Feature {

    @Dependency var httpClient: HTTPClientProtocol
    @Dependency var routerService: RouterServiceProtocol

    public init() {}

    public func build(fromRoute route: Route?) -> UIViewController {
        return FeatureOneViewController(
            httpClient: httpClient,
            routerService: routerService
        )
    }
}



