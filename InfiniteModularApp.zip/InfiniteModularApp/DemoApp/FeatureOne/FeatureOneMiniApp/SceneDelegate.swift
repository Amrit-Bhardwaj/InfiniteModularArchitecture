
import UIKit
import HTTPClientInterface
import RouterServiceInterface
import FeatureOne

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else {
            return
        }
        
        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = FeatureOneViewController.init(httpClient: HttpClientMock(), routerService: RouterServiceMock())
        window?.makeKeyAndVisible()
    }
}

// Mocking the Dependency of Feature One
class HttpClientMock: HTTPClientProtocol {}
struct EmptyRoute: Route {
    static var identifier: String = "Empty_Route"
}

class RouterServiceMock: RouterServiceProtocol, RouterServiceAnyRouteDecodingProtocol {
    func decodeAnyRoute(fromDecoder decoder: Decoder) throws -> (Route, String) {
        (EmptyRoute(), "")
    }
    
    
    func navigate(toRoute route: Route, fromView viewController: UIViewController, presentationStyle: PresentationStyle, animated: Bool, completion: (() -> Void)?) {}
}

