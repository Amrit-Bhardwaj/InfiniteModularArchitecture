//
//  FeatureFlagInterface.h
//  FeatureFlagInterface
//
//  Created by Amrit Bhardwaj on 11/01/23.
//

#import <Foundation/Foundation.h>

//! Project version number for FeatureFlagInterface.
FOUNDATION_EXPORT double FeatureFlagInterfaceVersionNumber;

//! Project version string for FeatureFlagInterface.
FOUNDATION_EXPORT const unsigned char FeatureFlagInterfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeatureFlagInterface/PublicHeader.h>


