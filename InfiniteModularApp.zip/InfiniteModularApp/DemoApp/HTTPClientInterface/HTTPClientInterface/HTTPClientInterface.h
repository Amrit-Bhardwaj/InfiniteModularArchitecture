//
//  HTTPClientInterface.h
//  HTTPClientInterface
//
//  Created by Amrit Bhardwaj on 16/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for HTTPClientInterface.
FOUNDATION_EXPORT double HTTPClientInterfaceVersionNumber;

//! Project version string for HTTPClientInterface.
FOUNDATION_EXPORT const unsigned char HTTPClientInterfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HTTPClientInterface/PublicHeader.h>


