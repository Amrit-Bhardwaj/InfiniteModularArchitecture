import UIKit

import RouterService
import RouterServiceInterface

import HTTPClient
import HTTPClientInterface

import FeatureFlagInterface
import FeatureFlag

import FeatureOne
import FeatureTwo

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    let routerService = RouterService()

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {

        guard let windowScene = (scene as? UIWindowScene) else {
            return
        }
        
        // 1. Manually Register Dependencies
        //2. We can have a shell Script to convert yml file to auto generated code to register dependencies as below:
        routerService.register(dependencyFactory: {
            return HTTPClient()
        }, forType: HTTPClientProtocol.self)
        routerService.register(dependencyFactory: {
            return FeatureFlag()
        }, forType: FeatureFlagProtocol.self)
        
        
        // Register feature Routes for Navigation
        routerService.register(routeHandler: FeatureTwoRouteHandler())
        routerService.register(routeHandler: FeatureOneRouteHandler())

        
        // Start the navigation Process
        let nav = routerService.navigationController(
            withInitialFeature: FeatureOne.self
        )
        
        window = UIWindow(windowScene: windowScene)
        window?.rootViewController = nav
        window?.makeKeyAndVisible()
    }
}


