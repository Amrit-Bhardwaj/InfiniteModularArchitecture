//
//  HTTPClient.swift
//  HTTPClient
//
//  Created by Amrit Bhardwaj on 16/12/22.
//

import HTTPClientInterface
import RouterServiceInterface

public class HTTPClient: HTTPClientProtocol {
    public init() {}
}
