//
//  FeatureFlag.h
//  FeatureFlag
//
//  Created by Amrit Bhardwaj on 11/01/23.
//

#import <Foundation/Foundation.h>

//! Project version number for FeatureFlag.
FOUNDATION_EXPORT double FeatureFlagVersionNumber;

//! Project version string for FeatureFlag.
FOUNDATION_EXPORT const unsigned char FeatureFlagVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeatureFlag/PublicHeader.h>


