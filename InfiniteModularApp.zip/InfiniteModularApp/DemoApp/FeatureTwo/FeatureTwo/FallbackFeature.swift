import UIKit
import RouterServiceInterface

public struct FallbackFeature: Feature {
    public init() {}
    
    public func build(fromRoute route: Route?) -> UIViewController {
        return FallbackController()
    }
}
