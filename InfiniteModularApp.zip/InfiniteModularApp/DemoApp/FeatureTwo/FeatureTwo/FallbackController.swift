import UIKit

// Fall back Feature
class FallbackController: UIViewController {
    
    init() {
           super.init(nibName: nil, bundle: nil)
       }

       required init?(coder: NSCoder) {
           fatalError()
       }

       override func loadView() {
           let view = UIView()

           view.backgroundColor = .gray
           let emptyStateLabel = UILabel()
           emptyStateLabel.numberOfLines = 0
           emptyStateLabel.lineBreakMode = .byWordWrapping
           emptyStateLabel.text = "Oops! I am a Fall back Feature. Use me for A/B tests or Mock Tests"
           view.addSubview(emptyStateLabel)
           emptyStateLabel.translatesAutoresizingMaskIntoConstraints = false
           emptyStateLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
           emptyStateLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
           emptyStateLabel.widthAnchor.constraint(equalToConstant: 200).isActive = true
           self.view = view
       }

}


