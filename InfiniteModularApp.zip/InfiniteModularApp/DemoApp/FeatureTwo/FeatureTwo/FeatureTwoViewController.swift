import RouterServiceInterface
import FeatureOneInterface
import UIKit

// Feature Two UI Screen
class FeatureTwoViewController: UIViewController {
    
    let route: Route?
    let routerService: RouterServiceProtocol

    init(route: Route?, routerService: RouterServiceProtocol) {
        self.route = route
        self.routerService = routerService
        super.init(nibName: nil, bundle: nil)
        self.navigationItem.setHidesBackButton(true, animated: true)
    }
    
    // Navigate to feature One using featureOneRoute
    @objc private func goToFeatureOne() {
        routerService.navigate(
            toRoute: FeatureOneRoute(),
            fromView: self,
            presentationStyle: Push(),
            animated: true
        )
    }
    
    required init?(coder: NSCoder) {
        fatalError()
    }

    override func loadView() {
        let view = UIView()
        view.backgroundColor = .green
        let featureLabel = UILabel()
        featureLabel.text = "FEATURE TWO"
        view.addSubview(featureLabel)
        featureLabel.translatesAutoresizingMaskIntoConstraints = false
        featureLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        featureLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        let button = UIButton(type: .system)
        button.setTitle("Go to FeatureOne", for: .normal)
        button.addTarget(self, action: #selector(goToFeatureOne), for: .touchUpInside)
        view.addSubview(button)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        button.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 64).isActive = true
        self.view = view
    }
}
