import RouterServiceInterface
import UIKit
import FeatureFlagInterface

public struct FeatureTwo: Feature {

    @Dependency var routerService: RouterServiceProtocol
    @Dependency var featureFlag: FeatureFlagProtocol
    
    public init() {}

    public func build(fromRoute route: Route?) -> UIViewController {
        return FeatureTwoViewController(route: route, routerService: routerService)
    }
    
    public func isEnabled() -> Bool {
        // Control this from feature flag or settings Bundle
        return featureFlag.isEnabled()
    }
    
    public func fallback(forRoute route: Route?) -> Feature.Type? {
        FallbackFeature.self
    }
}



