import RouterServiceInterface

public struct FeatureTwoRoute: Route {
    // This identifier can come from BE API response
    // to drive the navigation system of the app remotely
    public static let identifier: String = "featuretwo_main"
    public init() {}
}
