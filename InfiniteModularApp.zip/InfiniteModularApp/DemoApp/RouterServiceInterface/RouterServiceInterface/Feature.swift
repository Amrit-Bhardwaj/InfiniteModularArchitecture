import UIKit

public protocol Feature {
    func build(fromRoute route: Route?) -> UIViewController
    func resolve(withStore store: StoreInterface)
    
    // Implement this method if we want a feature to be controlled by feature flag, iOS version, settings bundle etc
    func isEnabled() -> Bool
    
    // Implement this function to return the fallback feature if the feature is disabled for a given route
    func fallback(forRoute route: Route?) -> Feature.Type?

    init()
}

extension Feature {
    
    public func resolve(withStore store: StoreInterface) {
        let mirror = Mirror(reflecting: self)
        for children in mirror.children {
            if let resolvable = children.value as? Resolvable {
                resolvable.resolve(withStore: store)
            }
        }
    }

    public func isEnabled() -> Bool { return true }
    public func fallback(forRoute route: Route?) -> Feature.Type? { return nil }
}
