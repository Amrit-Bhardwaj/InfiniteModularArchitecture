import Foundation
import UIKit

public protocol RouterServiceProtocol: RouterServiceAnyRouteDecodingProtocol {
    func navigate(
        toRoute route: Route,
        fromView viewController: UIViewController,
        presentationStyle: PresentationStyle,
        animated: Bool,
        completion: (() -> Void)?
    )
}

public extension RouterServiceProtocol {
    func navigate(
        toRoute route: Route,
        fromView viewController: UIViewController,
        presentationStyle: PresentationStyle,
        animated: Bool
    ) {
        navigate(
            toRoute: route,
            fromView: viewController,
            presentationStyle: presentationStyle,
            animated: animated,
            completion: nil
        )
    }
}

public typealias DependencyFactory = () -> AnyObject

public protocol RouterServiceRegistrationProtocol {
    func register<T>(dependencyFactory: @escaping DependencyFactory, forType metaType: T.Type)
    func register(routeHandler: RouteHandler)
}

public protocol RouterServiceScopeProtocol {
    // This function Will be used to define service scopes
    // E.g. The Profile service cant enter the scope if the user is not logged in
    // E.g. After the user leaves a scope we deallocate all its dependencies and free up memory.
    func register(scope: String)
    func enter(scope: String)
    func leave(scope: String)
}
