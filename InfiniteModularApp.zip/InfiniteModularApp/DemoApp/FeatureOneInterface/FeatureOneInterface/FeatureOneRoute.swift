import RouterServiceInterface

public struct FeatureOneRoute: Route {
    // This identifier can come from BE API response
    // to drive the navigation system of the app remotely
    public static let identifier: String = "featureone_main"
    public init() {}
}
