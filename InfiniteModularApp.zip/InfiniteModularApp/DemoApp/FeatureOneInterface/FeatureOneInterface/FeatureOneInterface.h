//
//  FeatureOneInterface.h
//  FeatureOneInterface
//
//  Created by Amrit Bhardwaj on 16/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for FeatureOneInterface.
FOUNDATION_EXPORT double FeatureOneInterfaceVersionNumber;

//! Project version string for FeatureOneInterface.
FOUNDATION_EXPORT const unsigned char FeatureOneInterfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeatureOneInterface/PublicHeader.h>


